package Controller;

import Model.Model;
import View.View;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.MouseListener;

public class Controller
{

    Model model;
    View view;
    int sortChoice = 0;

    public Controller(Model m, View v)
    {
        model = m;
        view = v;
        view.initialSetup();

        view.CenterInitialSetup(model.cd.getLinesToDisplay(), model.cd.getHeaders().size());
        view.EastInitialSetup(model.gd.getLines(0, 8), model.gd.getHeaders());

        model.cd.setBegin(0);
        model.gd.setBegin(0);

        view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
        view.EastUpdate(model.gd.getLines(model.gd.getBegin(), model.gd.getEnd()), model.gd.getHeaders());

        addListeners();
        addWestListeners();
        addCenterListeners();
        addNorthListeners();
    }

    private void addNorthListeners()
    {
        view.getInitialframe().getInitialPanel().getNp().getTextBox().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent Ae)
            {

                String searched = view.getInitialframe().getInitialPanel().getNp().getTextBox().getText();
                System.out.println(searched);
                model.cd.search(searched);
                if (model.cd.isSearchBoolean() == true)
                {
                    System.out.println("true");
                    view.getInitialframe().getInitialPanel().getNp().getTextBox().setOpaque(true);
                    view.getInitialframe().getInitialPanel().getNp().getTextBox().setBackground(Color.white);
                    model.cd.searchSort(view.getInitialframe().getInitialPanel().getNp().getTextBox().getText());
                    view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
                } else
                {
                    System.out.println("false");
                    view.getInitialframe().getInitialPanel().getNp().getTextBox().setOpaque(true);
                    view.getInitialframe().getInitialPanel().getNp().getTextBox().setBackground(Color.red);
                }
            }
        }
        );
    }

    private void addListeners()
    {
        view.getInitialframe().getInitialPanel().getCp().addMouseWheelListener(
                new MouseWheelListener()
        {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e)
            {
                int units = e.getUnitsToScroll();
                model.cd.setBegin(model.cd.getBegin() + units);
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );
    }

    private void addWestListeners()
    {
        view.getInitialframe().getInitialPanel().getWp().getSelection().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent Ae)
            {
                view.getInitialframe().getInitialPanel().getWp().getSelection().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getWp().getSelection().setForeground(Color.WHITE);

                view.getInitialframe().getInitialPanel().getWp().getMerge().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getMerge().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getWp().getQuick().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getQuick().setForeground(Color.BLACK);

                sortChoice = 1;
                //selection
            }

        }
        );
        view.getInitialframe().getInitialPanel().getWp().getMerge().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent Ae)
            {
                view.getInitialframe().getInitialPanel().getWp().getSelection().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getSelection().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getWp().getMerge().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getWp().getMerge().setForeground(Color.WHITE);

                view.getInitialframe().getInitialPanel().getWp().getQuick().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getQuick().setForeground(Color.BLACK);

                sortChoice = 2;
                //merge/arraylist[]
            }

        }
        );

        view.getInitialframe().getInitialPanel().getWp().getQuick().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent Ae)
            {
                view.getInitialframe().getInitialPanel().getWp().getSelection().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getSelection().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getWp().getMerge().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getWp().getMerge().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getWp().getQuick().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getWp().getQuick().setForeground(Color.WHITE);

                sortChoice = 3;
                //quick/array[]
            }

        }
        );

    }

    private void addCenterListeners()
    {

        view.getInitialframe().getInitialPanel().getCp().getNameLabel().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //NAME
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setForeground(Color.WHITE);

                view.getInitialframe().getInitialPanel().getCp().getGenEds().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getGenEds().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getDescription().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getDescription().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getCredits().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getCredits().setForeground(Color.BLACK);

                model.cd.sort(sortChoice, model.cd.courseID(0));
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );

        view.getInitialframe().getInitialPanel().getCp().getGenEds().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //GENEDS
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getGenEds().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getCp().getGenEds().setForeground(Color.WHITE);

                view.getInitialframe().getInitialPanel().getCp().getDescription().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getDescription().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getCredits().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getCredits().setForeground(Color.BLACK);

                model.cd.sort(sortChoice, model.cd.courseID(1));
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );

        view.getInitialframe().getInitialPanel().getCp().getDescription().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //DESCRIPTION
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getGenEds().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getGenEds().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getDescription().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getCp().getDescription().setForeground(Color.WHITE);

                view.getInitialframe().getInitialPanel().getCp().getCredits().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getCredits().setForeground(Color.BLACK);

                model.cd.sort(sortChoice, model.cd.courseID(2));
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );

        view.getInitialframe().getInitialPanel().getCp().getCredits().addActionListener(
                new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //CREDITS
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getNameLabel().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getGenEds().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getGenEds().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getDescription().setBackground(Color.LIGHT_GRAY);
                view.getInitialframe().getInitialPanel().getCp().getDescription().setForeground(Color.BLACK);

                view.getInitialframe().getInitialPanel().getCp().getCredits().setBackground(Color.BLACK);
                view.getInitialframe().getInitialPanel().getCp().getCredits().setForeground(Color.WHITE);

                model.cd.sort(sortChoice, model.cd.courseID(3));
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );
    }
}
