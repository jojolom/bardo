package View;

import Model.TableData;
import Model.TableMember;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;
import java.util.*;
import Model.genEdData;

public class EastPanel extends JPanel
{

    private ArrayList<JLabel> labels;
    private ArrayList<JButton> buttons;

    public void UpdatePanel(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {

        for (int i = 0; i < HeaderHolder.size(); i++)
        {
            getLabels().get(i).setText(HeaderHolder.get(i));
        }

        for (int i = 0; i < LinesHolder.size(); i++)
        {
            ArrayList<String> inside = LinesHolder.get(i);

            for (int j = 0; j < inside.size(); j++)
            {
                getButtons().get(HeaderHolder.size() * i + j).setText(inside.get(j));
            }
        }
        validate();
        repaint();
    }

    public void EastInitialSetup(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {

        int numHeaders = HeaderHolder.size();
        int numRows = LinesHolder.size();

        setLayout(new GridLayout(numRows + 1, numHeaders, 5, 5));
        setBackground(Color.DARK_GRAY);

        for (int i = 0; i < numHeaders; i++)
        {
            JLabel headerLabel = new JLabel();
            headerLabel.setBackground(Color.white);
            headerLabel.setForeground(Color.black);
            headerLabel.setOpaque(true);
            headerLabel.setHorizontalAlignment(SwingConstants.CENTER);

            add(headerLabel);
            getLabels().add(headerLabel);
        }

        for (int i = 0; i < numRows; i++)
        {
            for (int j = 0; j < numHeaders; j++)
            {
                JButton memberButton = new JButton();
                memberButton.setBackground(new Color(178, 122, 122));
                memberButton.setForeground(Color.white);
                memberButton.setOpaque(true);
                add(memberButton);
                getButtons().add(memberButton);
            }
        }
        validate();
        repaint();

    }

    public EastPanel()
    {
        super();
        labels = new ArrayList<JLabel>();
        buttons = new ArrayList<JButton>();
//        this.data = new genEdData();
//        this.data.loadTable();

    }

    /**
     * @return the labels
     */
    public ArrayList<JLabel> getLabels()
    {
        return labels;
    }

    /**
     * @param labels the labels to set
     */
    public void setLabels(ArrayList<JLabel> labels)
    {
        this.labels = labels;
    }

    /**
     * @return the buttons
     */
    public ArrayList<JButton> getButtons()
    {
        return buttons;
    }

    /**
     * @param buttons the buttons to set
     */
    public void setButtons(ArrayList<JButton> buttons)
    {
        this.buttons = buttons;
    }
}
