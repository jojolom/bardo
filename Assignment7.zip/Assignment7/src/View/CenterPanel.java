package View;

import Model.TableData;
import Model.TableMember;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.*;
import java.util.*;
import Model.courseData;

public class CenterPanel extends JPanel
{

    private ArrayList<JButton> HeaderButtons;
    private ArrayList<JButton> buttons;

    private int numHeaders;
    private int numRows;

    private JButton NameLabel;
    private JButton GenEds;
    private JButton Description;
    private JButton Credits;

    public void UpdatePanel(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {
        for (int i = 0; i < HeaderHolder.size(); i++)
        {
            getHeaderButtons().get(i).setText(HeaderHolder.get(i));
        }

        for (int i = 0; i < LinesHolder.size(); i++)
        {
            ArrayList<String> inside = LinesHolder.get(i);

            for (int j = 0; j < inside.size(); j++)
            {
                getButtons().get(HeaderHolder.size() * i + j).setText(inside.get(j));
            }
        }
        repaint();
    }

    public void CenterInitialSetup(int LinesHolder, int HeaderHolder)
    {

        int numHeaders = HeaderHolder;
        int numRows = LinesHolder;
        setLayout(new GridLayout(numRows + 1, numHeaders, 5, 5));
        setBackground(Color.DARK_GRAY);

        Font fred = new Font("Sans", Font.BOLD + Font.ITALIC, 12);

        setNameLabel(new JButton());
        getNameLabel().setBackground(Color.lightGray);
        getNameLabel().setForeground(Color.darkGray);
        getNameLabel().setFont(fred);
        getNameLabel().setOpaque(true);
        getNameLabel().setHorizontalAlignment(SwingConstants.CENTER);
        add(getNameLabel());
        getHeaderButtons().add(getNameLabel());

        setGenEds(new JButton());
        getGenEds().setBackground(Color.lightGray);
        getGenEds().setForeground(Color.darkGray);
        getGenEds().setFont(fred);
        getGenEds().setOpaque(true);
        getGenEds().setHorizontalAlignment(SwingConstants.CENTER);
        add(getGenEds());
        getHeaderButtons().add(getGenEds());

        setDescription(new JButton());
        getDescription().setBackground(Color.lightGray);
        getDescription().setForeground(Color.darkGray);
        getDescription().setFont(fred);
        getDescription().setOpaque(true);
        getDescription().setHorizontalAlignment(SwingConstants.CENTER);
        add(getDescription());
        getHeaderButtons().add(getDescription());

        setCredits(new JButton());
        getCredits().setBackground(Color.lightGray);
        getCredits().setForeground(Color.darkGray);
        getCredits().setFont(fred);
        getCredits().setOpaque(true);
        getCredits().setHorizontalAlignment(SwingConstants.CENTER);
        add(getCredits());
        getHeaderButtons().add(getCredits());

        for (int i = 0; i < numRows; i++)
        {
            for (int j = 0; j < numHeaders; j++)
            {
                JButton memberButton = new JButton();
                add(memberButton);
                getButtons().add(memberButton);
            }
        }
        repaint();
    }

    public CenterPanel()
    {
        super();
        HeaderButtons = new ArrayList<JButton>();
        buttons = new ArrayList<JButton>();
    }

    /**
     * @return the buttons
     */
    public ArrayList<JButton> getButtons()
    {
        return buttons;
    }

    /**
     * @param buttons the buttons to set
     */
    public void setButtons(ArrayList<JButton> buttons)
    {
        this.buttons = buttons;
    }

    /**
     * @return the HeaderButtons
     */
    public ArrayList<JButton> getHeaderButtons()
    {
        return HeaderButtons;
    }

    /**
     * @param HeaderButtons the HeaderButtons to set
     */
    public void setHeaderButtons(ArrayList<JButton> HeaderButtons)
    {
        this.HeaderButtons = HeaderButtons;
    }

    /**
     * @return the NameLabel
     */
    public JButton getNameLabel()
    {
        return NameLabel;
    }

    /**
     * @param NameLabel the NameLabel to set
     */
    public void setNameLabel(JButton NameLabel)
    {
        this.NameLabel = NameLabel;
    }

    /**
     * @return the GenEds
     */
    public JButton getGenEds()
    {
        return GenEds;
    }

    /**
     * @param GenEds the GenEds to set
     */
    public void setGenEds(JButton GenEds)
    {
        this.GenEds = GenEds;
    }

    /**
     * @return the Description
     */
    public JButton getDescription()
    {
        return Description;
    }

    /**
     * @param Description the Description to set
     */
    public void setDescription(JButton Description)
    {
        this.Description = Description;
    }

    /**
     * @return the Credits
     */
    public JButton getCredits()
    {
        return Credits;
    }

    /**
     * @param Credits the Credits to set
     */
    public void setCredits(JButton Credits)
    {
        this.Credits = Credits;
    }

}
