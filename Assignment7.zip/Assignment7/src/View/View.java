package View;

import Model.TableMember;
import java.util.ArrayList;
import javax.swing.*;

public class View
{

    private InitialFrame iframe;

    public View()
    {
        iframe = new InitialFrame();
    }

    public void initialSetup()
    {
        //add or update whatever is needed to the initial setup of the graphics
        iframe.repaint();
    }

    public void EastInitialSetup(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {
        iframe.getInitialPanel().getEp().EastInitialSetup(LinesHolder, HeaderHolder);
        //add or update whatever is needed to the initial setup of the graphics
        iframe.repaint();
    }

    public void EastUpdate(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {
        iframe.getInitialPanel().getEp().UpdatePanel(LinesHolder, HeaderHolder);
        iframe.repaint();
    }

    public void CenterInitialSetup(int LinesHolder, int HeaderHolder)
    {
        iframe.getInitialPanel().getCp().CenterInitialSetup(LinesHolder, HeaderHolder);
        //add or update whatever is needed to the initial setup of the graphics
        iframe.repaint();
    }

    public void CenterUpdate(ArrayList<ArrayList<String>> LinesHolder, ArrayList<String> HeaderHolder)
    {
        iframe.getInitialPanel().getCp().UpdatePanel(LinesHolder, HeaderHolder);
        iframe.repaint();
    }

    public InitialFrame getInitialframe()
    {
        return iframe;
    }

    public void setInitialframe(InitialFrame iframe)
    {
        this.iframe = iframe;
    }

}
