package View;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import Model.genEdData;

public class InitialPanel extends JPanel
{

    private NorthPanel np;
    //   private SouthPanel sp;
    private EastPanel ep;
    private WestPanel wp;
    private CenterPanel cp;

    public InitialPanel()
    {
        super();
        BorderLayout bl = new BorderLayout();
        setLayout(bl);
        np = new NorthPanel();
        //       sp = new SouthPanel();
        ep = new EastPanel();
        wp = new WestPanel();
        cp = new CenterPanel();
        add(np, BorderLayout.NORTH);
        //      add(sp, BorderLayout.SOUTH);
        add(ep, BorderLayout.EAST);
        add(wp, BorderLayout.WEST);
        add(cp, BorderLayout.CENTER);
    }

    /**
     * @return the np
     */
    public NorthPanel getNp()
    {
        return np;
    }

    /**
     * @param np the np to set
     */
    public void setNp(NorthPanel np)
    {
        this.np = np;
    }

//    /**
//     * @return the sp
//     */
//    public SouthPanel getSp()
//    {
//        return sp;
//    }
//
//    /**
//     * @param sp the sp to set
//     */
//    public void setSp(SouthPanel sp)
//    {
//        this.sp = sp;
//    }
    /**
     * @return the ep
     */
    public EastPanel getEp()
    {
        return ep;
    }

    /**
     * @param ep the ep to set
     */
    public void setEp(EastPanel ep)
    {
        this.ep = ep;
    }

    /**
     * @return the wp
     */
    public WestPanel getWp()
    {
        return wp;
    }

    /**
     * @param wp the wp to set
     */
    public void setWp(WestPanel wp)
    {
        this.wp = wp;
    }

    /**
     * @return the cp
     */
    public CenterPanel getCp()
    {
        return cp;
    }

    /**
     * @param cp the cp to set
     */
    public void setCp(CenterPanel cp)
    {
        this.cp = cp;
    }

}
