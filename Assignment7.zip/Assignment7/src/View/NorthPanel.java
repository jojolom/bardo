package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;
import java.util.*;

public class NorthPanel extends JPanel
{

    private JTextField textBox;

    public NorthPanel()
    {
        super();
        setBackground(Color.black);
        textBox = new JTextField("Please enter your inquiry");
        add(textBox);
    }

    /**
     * @return the text
     */
    public JTextField getTextBox()
    {
        return textBox;
    }

    /**
     * @param text the text to set
     */
    public void setTextBox(JTextField textBox)
    {
        this.textBox = textBox;
    }
}
