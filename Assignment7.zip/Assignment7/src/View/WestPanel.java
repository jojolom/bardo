package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;
import java.util.*;

public class WestPanel extends JPanel
{

    private JButton choose;
    private JButton selection;
    private JButton merge;
    private JButton quick;

    public WestPanel()
    {
        super();
        setBackground(Color.DARK_GRAY);
        setLayout(new GridLayout(4, 1));

        choose = new JButton("Choose a SORT type.");
        choose.setBackground(Color.DARK_GRAY);
        choose.setForeground(Color.white);
        add(choose);

        selection = new JButton("Selection/Write Yourself");
        selection.setBackground(Color.LIGHT_GRAY);
        add(selection);

        merge = new JButton("Merge/ArrayList()");
        merge.setBackground(Color.LIGHT_GRAY);
        add(merge);

        quick = new JButton("Quick/Arrays[]");
        quick.setBackground(Color.LIGHT_GRAY);
        add(quick);
    }

    //to call you would have to do selectionSelect(WestPanel.selection)
    public void UpdatePanel(JButton buttonHolder)
    {
        JButton selection = buttonHolder;
        selection.setBackground(Color.DARK_GRAY);
        selection.setForeground(Color.white);
    }

    /**
     * @return the choose
     */
    public JButton getChoose()
    {
        return choose;
    }

    /**
     * @param choose the choose to set
     */
    public void setChoose(JButton choose)
    {
        this.choose = choose;
    }

    /**
     * @return the selection
     */
    public JButton getSelection()
    {
        return selection;
    }

    /**
     * @param selection the selection to set
     */
    public void setSelection(JButton selection)
    {
        this.selection = selection;
    }

    /**
     * @return the merge
     */
    public JButton getMerge()
    {
        return merge;
    }

    /**
     * @param merge the merge to set
     */
    public void setMerge(JButton merge)
    {
        this.merge = merge;
    }

    /**
     * @return the quick
     */
    public JButton getQuick()
    {
        return quick;
    }

    /**
     * @param quick the quick to set
     */
    public void setQuick(JButton quick)
    {
        this.quick = quick;
    }

}
