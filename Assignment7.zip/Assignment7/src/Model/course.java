package Model;

import java.util.ArrayList;

public class course implements TableMember
{

    private courseName Name;
    private ArrayList<genEd> GenEds;
    private String Description;
    private Integer Credits;
    private String PreReqs;
    private String Comments;

    public course()
    {

    }

    /**
     * getAttribute returns the value of selected attribute of a class. The
     * attribute is returned as a String independently of its original type.
     *
     * @param n represents the index of the selected attribute 0 means the first
     * attribute
     *
     * @return a String with the value of the selected attribute.
     */
    public String getAttribute(int n)
    {
        if (n == 0)
        {
            return Name.toString();
        }

        if (n == 1)
        {
            return GenEds.toString();
        }

        if (n == 2)
        {
            return Description;
        }

        if (n == 3)
        {
            return Credits.toString();
        }

        if (n == 4)
        {
            return PreReqs;
        }

        if (n == 5)
        {
            return Comments;
        }
        return null;
    }

    /**
     * getAttributes returns the value of all attributes of a class. The
     * attributes are returned as a String Array.
     *
     * @return an array of string with the value of all attributes.
     */
    public ArrayList<String> getAttributes()
    {
        ArrayList<String> s = new ArrayList<String>();
        for (int i = 0; i < 6; i++)
        {
            s.add(getAttribute(i));
        }
        return s;
    }

    /**
     * getAttributeName returns the name of selected attribute of a class The
     * attribute is returned as a String
     *
     * @param n represents the index of the selected attribute 0 means the first
     * attribute
     *
     * @return a String with the value of the name of the selected attribute
     */
    public String getAttributeName(int n)
    {
        if (n == 0)
        {
            return "Name";
        }

        if (n == 1)
        {
            return "GenEds";
        }

        if (n == 2)
        {
            return "Description";
        }

        if (n == 3)
        {
            return "Credits";
        }

        if (n == 4)
        {
            return "PreReqs";
        }

        if (n == 5)
        {
            return "Comments";
        }
        return null;
    }

    /**
     * getAttributesNames returns the value of all names of the attributes of a
     * class. The names of the attributes are returned as a String Array.
     *
     * @return an array of string with the names of all attributes.
     */
    public ArrayList<String> getAttributesNames()
    {
        ArrayList<String> s = new ArrayList<String>();
        for (int i = 0; i < 6; i++)
        {
            s.add(getAttributeName(i));
        }
        return s;
    }

    public course(String a, String b, String c, String d, int e, String f, String g)
    {
        Name = new courseName(a, b, c);
        GenEds = new ArrayList<>();
        Description = d;
        Credits = e;
        PreReqs = f;
        Comments = g;
    }

    public course(String a, String b, String c)
    {
        Name = new courseName(a, b, c);
        GenEds = new ArrayList<>();
        Description = "";
        Credits = 0;
        PreReqs = "";
        Comments = "";
    }

    /**
     * @return the name
     */
    public courseName getName()
    {
        return Name;
    }

    /**
     * @param name the name to set
     */
    public void setName(courseName name)
    {
        this.Name = name;
    }

    /**
     * @return the genEds
     */
    public ArrayList<genEd> getGenEds()
    {
        return GenEds;
    }

    /**
     * @param genEds the genEds to set
     */
    public void setGenEds(ArrayList<genEd> genEds)
    {
        this.GenEds = genEds;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return Description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.Description = description;
    }

    /**
     * @return the credits
     */
    public int getCredits()
    {
        return Credits;
    }

    /**
     * @param credits the credits to set
     */
    public void setCredits(int credits)
    {
        this.Credits = credits;
    }

    /**
     * @return the preReqs
     */
    public String getPreReqs()
    {
        return PreReqs;
    }

    /**
     * @param preReqs the preReqs to set
     */
    public void setPreReqs(String preReqs)
    {
        this.PreReqs = preReqs;
    }

    /**
     * @return the comments
     */
    public String getComments()
    {
        return Comments;
    }

    /**
     * @param comments the comments to set
     */
    public void setComments(String comments)
    {
        this.Comments = comments;
    }

}
