package Model;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class courseData implements TableData
{

    /**
     * @return the sortCourseByName
     */
    private ArrayList<course> courses;
    private int[] selectedFields;
    private int begin = 0;
    private int linesToDisplay = 20;
    private int end = 19;
    private HashMap<String, course> searchByName = new HashMap<>();
    private boolean searchBoolean;

    public courseData()
    {
        courses = new ArrayList<>();
        loadTable();
        selectedFields = new int[0];

        for (int i = 0; i < courses.size(); i++)
        {
            searchByName.put(courses.get(i).getName().getCourseNameFormatted(), courses.get(i));
        }
    }
    
    public boolean search(String searched)
            {
                if (searchByName.containsKey(searched))
                {
                    searchBoolean = true;
                    return searchBoolean;
                }
                else{
                    searchBoolean = false;
                    return searchBoolean;
                } 
            }

    public void searchSort(String searched)
    {
        while (!(courses.get(0).getName().getCourseNameFormatted().equals(searched)))
        {
            for (int j = 0; j < 1; j++)
            {
                courseName a = courses.get(0).getName();
                int i;
                for (i = 0; i < courses.size() - 1; i++)
                {
                    courses.get(i).setName(courses.get(i + 1).getName());
                }
                courses.get(i).setName(a);
            }
        }
    }
    
    public String courseID(int ID)
    {
        return courses.get(0).getAttributeName(ID); 
    }

    private Comparator<course> sortName = new Comparator<course>()
    {
        @Override
        public int compare(course c1, course c2)
        {
            return c1.getAttribute(0).compareTo(c2.getAttribute(0));
        }
    };

    private Comparator<course> sortGenEds = new Comparator<course>()
    {
        @Override
        public int compare(course c1, course c2)
        {
            return c1.getAttribute(1).compareTo(c2.getAttribute(1));
        }
    };

    private Comparator<course> sortDescription = new Comparator<course>()
    {
        @Override
        public int compare(course c1, course c2)
        {
            return c1.getAttribute(2).compareTo(c2.getAttribute(2));
        }
    };

    private Comparator<course> sortCredits = new Comparator<course>()
    {
        @Override
        public int compare(course c1, course c2)
        {
            if (c1.getCredits() < (c2.getCredits()))
            {
                return -1;
            }
            if (c1.getCredits() == (c2.getCredits()))
            {
                return 0;
            }
            return 1;
        }
    };

    public void selectionSort(Comparator<course> run)
    {
        for (int i = 0; i < courses.size() - 1; ++i)
        {
            int min = i;
            for (int j = i + 1; j < courses.size(); ++j)
            {
                if (run.compare(courses.get(j), courses.get(min)) < 0)
                {
                    min = j;
                }
            }
            course temp = courses.get(i);
            courses.set(i, courses.get(min));
            courses.set(min, temp);
        }
    }

    public void sort(int sortType, String attributeToSort)
    {
        System.out.println(sortType + attributeToSort);
        Comparator<course> attributeToCompare;

        if (sortType == 1 && attributeToSort.equals("Name"))
        {
            attributeToCompare = sortName;
            this.selectionSort(attributeToCompare);
        } else if (sortType == 2 && attributeToSort.equals("Name"))
        {
            attributeToCompare = sortName;
            System.out.println(courses);
            Collections.sort(getCourses(), attributeToCompare);
            System.out.println(courses);
        } else if (sortType == 3 && attributeToSort.equals("Name"))
        {
            attributeToCompare = sortName;
            course[] sortedCourses = getCoursesAsArray();
            Arrays.sort(sortedCourses, attributeToCompare);
            setCoursesFromArray(sortedCourses);
        } else if (sortType == 1 && attributeToSort.equals("GenEds"))
        {
            attributeToCompare = sortGenEds;
            this.selectionSort(attributeToCompare);
        } else if (sortType == 2 && attributeToSort.equals("GenEds"))
        {
            attributeToCompare = sortGenEds;
            Collections.sort(getCourses(), attributeToCompare);
        } else if (sortType == 3 && attributeToSort.equals("GenEds"))
        {
            attributeToCompare = sortGenEds;
            course[] sortedCourses = getCoursesAsArray();
            Arrays.sort(sortedCourses, attributeToCompare);
            setCoursesFromArray(sortedCourses);
        } else if (sortType == 1 && attributeToSort.equals("Description"))
        {
            attributeToCompare = sortDescription;
            this.selectionSort(attributeToCompare);
        } else if (sortType == 2 && attributeToSort.equals("Description"))
        {
            attributeToCompare = sortDescription;
            Collections.sort(getCourses(), attributeToCompare);
        } else if (sortType == 3 && attributeToSort.equals("Description"))
        {
            attributeToCompare = sortDescription;
            course[] sortedCourses = getCoursesAsArray();
            Arrays.sort(sortedCourses, attributeToCompare);
            setCoursesFromArray(sortedCourses);
        } else if (sortType == 1 && attributeToSort.equals("Credits"))
        {
            attributeToCompare = sortCredits;
            this.selectionSort(attributeToCompare);
        } else if (sortType == 2 && attributeToSort.equals("Credits"))
        {
            attributeToCompare = sortCredits;
            Collections.sort(getCourses(), attributeToCompare);
        } else if (sortType == 3 && attributeToSort.equals("Credits"))
        {
            attributeToCompare = sortCredits;
            course[] sortedCourses = getCoursesAsArray();
            Arrays.sort(sortedCourses, attributeToCompare);
            setCoursesFromArray(sortedCourses);
        }
    }

    public ArrayList getTable()
    {
        return getCourses();
    }

    public void loadTable()
    {
        ReadCoursesFromXML();
    }

    /**
     * setSelectedFields receives an array which contains a list of selected
     * attributes.
     *
     * @param selected represents the an int[] array with the index positions of
     * selected attributes 0 is the first attribute
     */
    public void setSelectedFields(int[] selected)
    {
        selectedFields = selected;
    }

    /**
     *
     * @return an int[] array with the index positions of selected attributes
     */
    public int[] getSelectedFields()
    {
        return selectedFields;
    }

    /**
     *
     * @return an ArrayList of Strings with the attribute names of a class that
     * implements this interface.
     */
    public ArrayList<String> getHeaders()
    {
        if (selectedFields.length == 0)
        {
            return getCourses().get(0).getAttributesNames();
        }

        ArrayList<String> headers = new ArrayList<String>();

        for (int i : selectedFields)
        {
            headers.add(getCourses().get(0).getAttributeName(i));
        }
        return headers;
    }

    /**
     * @return the begin
     */
    public int getBegin()
    {
        return begin;
    }

    /**
     * @param begin the begin to set
     */
    public void setBegin(int b)
    {
        //Bounds of begin
        begin = b;
        if (this.begin < 0)
        {
            this.begin = 0;
        }
        if (this.begin > getCourses().size() - linesToDisplay)
        {
            this.begin = getCourses().size() - linesToDisplay;
        }
        this.end = this.begin + linesToDisplay - 1;
    }

    /**
     * @return the linesToDisplay
     */
    public int getLinesToDisplay()
    {
        return linesToDisplay;
    }

    /**
     * @param linesToDisplay the linesToDisplay to set
     */
    public void setLinesToDisplay(int linesToDisplay)
    {
        this.linesToDisplay = linesToDisplay;
    }

    /**
     * @return the end
     */
    public int getEnd()
    {
        return end;
    }

    /**
     * @param end the end to set
     */
    public void setEnd(int end)
    {
        this.end = end;
    }

    /**
     * getLine returns an ArrayList of Strings with all the attribute values of
     * an object in the data ArrayList
     *
     * @param line represents the object position in the data ArrayList
     * @return
     */
    public ArrayList<String> getLine(int line)
    {
        if (selectedFields.length == 0)
        {
            return getCourses().get(line).getAttributes();
        }

        ArrayList<String> lists = new ArrayList<String>();
        for (int x : selectedFields)
        {
            lists.add(getCourses().get(line).getAttribute(x));
        }
        return lists;
    }

    /**
     * getLines return a list of lines defined by a range. It uses getLine(int
     * line) method.
     *
     * @param firstLine is the first line of a range to be returned
     * @param lastLine is the last line of a range to be returned
     * @return an ArrayList of ArrayLists with Strings
     */
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine)
    {
        ArrayList<ArrayList<String>> lines = new ArrayList<ArrayList<String>>();

        for (int i = firstLine; i < lastLine + 1; i++)
        {
            lines.add(getLine(i));
        }
        return lines;
    }

    public void ReadCoursesFromXML()
    {
        try
        {
            course cs;
            XMLDecoder decoder;
            decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("./src/Model/CourseTable.xml")));
            cs = new course();
            while (cs != null)
            {
                try
                {
                    cs = (course) decoder.readObject();
                    getCourses().add(cs);

                } catch (ArrayIndexOutOfBoundsException theend)
                {
                    //System.out.println("end of file");
                    break;
                }
            }
            decoder.close();
        } catch (Exception xx)
        {
            xx.printStackTrace();
        }
    }

    /**
     * @return the courses
     */
    public ArrayList<course> getCourses()
    {
        return courses;
    }

    public course[] getCoursesAsArray()
    {
        course coursesArray[];
        coursesArray = courses.toArray(new course[courses.size()]);
        return coursesArray;
    }

    public void setCoursesFromArray(course[] courses)
    {
        this.courses = new ArrayList<course>(Arrays.asList(courses));
    }

    /**
     * @param courses the courses to set
     */
    public void setCourses(ArrayList<course> courses)
    {
        this.courses = courses;
    }

    /**
     * @return the searchByName
     */
    public HashMap<String, course> getSearchByName()
    {
        return searchByName;
    }

    /**
     * @param searchByName the searchByName to set
     */
    public void setSearchByName(HashMap<String, course> searchByName)
    {
        this.searchByName = searchByName;
    }

    /**
     * @return the searchBoolean
     */
    public boolean isSearchBoolean()
    {
        return searchBoolean;
    }

    /**
     * @param searchBoolean the searchBoolean to set
     */
    public void setSearchBoolean(boolean searchBoolean)
    {
        this.searchBoolean = searchBoolean;
    }

}
