package Model;

import java.util.ArrayList;

public class genEd implements TableMember
{

    private String Code;
    private String Description;

    public genEd()
    {
    }

    /**
     * getAttribute returns the value of selected attribute of a class. The
     * attribute is returned as a String independently of its original type.
     *
     * @param n represents the index of the selected attribute 0 means the first
     * attribute
     *
     * @return a String with the value of the selected attribute.
     */
    public String getAttribute(int n)
    {
        if (n == 0)
        {
            return Code;
        }

        if (n == 1)
        {
            return Description;
        }

        return null;
    }

    /**
     * getAttributes returns the value of all attributes of a class. The
     * attributes are returned as a String Array.
     *
     * @return an array of string with the value of all attributes.
     */
    public ArrayList<String> getAttributes()
    {
        ArrayList<String> s = new ArrayList<String>();
        for (int i = 0; i < 2; i++)
        {
            s.add(getAttribute(i));
        }
        return s;
    }

    /**
     * getAttributeName returns the name of selected attribute of a class The
     * attribute is returned as a String
     *
     * @param n represents the index of the selected attribute 0 means the first
     * attribute
     *
     * @return a String with the value of the name of the selected attribute
     */
    public String getAttributeName(int n)
    {
        if (n == 0)
        {
            return "Code";
        }

        if (n == 1)
        {
            return "Description";
        }
        return null;
    }

    /**
     * getAttributesNames returns the value of all names of the attributes of a
     * class. The names of the attributes are returned as a String Array.
     *
     * @return an array of string with the names of all attributes.
     */
    public ArrayList<String> getAttributesNames()
    {
        ArrayList<String> s = new ArrayList<String>();
        for (int i = 0; i < 2; i++)
        {
            s.add(getAttributeName(i));
        }
        return s;
    }

    public genEd(String a, String b)
    {
        Description = a;
        Code = b;
    }

    public String getInfo()
    {
        return "genEd{" + "description=" + getDescription() + ", code=" + getCode() + "}";
    }

    @Override
    public String toString()
    {
        return getCode();
    }

    /**
     * @return the Code
     */
    public String getCode()
    {
        return Code;
    }

    /**
     * @param Code the Code to set
     */
    public void setCode(String Code)
    {
        this.Code = Code;
    }

    /**
     * @return the Description
     */
    public String getDescription()
    {
        return Description;
    }

    /**
     * @param Description the Description to set
     */
    public void setDescription(String Description)
    {
        this.Description = Description;
    }

}
