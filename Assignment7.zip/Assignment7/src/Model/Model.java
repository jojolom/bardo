package Model;

public class Model
{

    public courseData cd;
    public genEdData gd;

    public Model()
    {
        cd = new courseData();

        int[] selectedCourses =
        {
            0, 1, 2, 3
        };




        cd.setSelectedFields(selectedCourses);

        int[] selectedGenEd = new int[0];

        gd = new genEdData();
        gd.setSelectedFields(selectedGenEd);
    }
}
