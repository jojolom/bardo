package Model;

import java.util.ArrayList;

public class genEdData implements TableData
{

    private ArrayList<genEd> genEds;
    private int[] selectedFields;

    private int begin = 0;
    private int linesToDisplay = 9;
    private int end = 8;

    public genEdData()
    {
        genEds = new ArrayList<>();
        loadTable();
        selectedFields = new int[0];
    }

    public void loadTable()
    {
        CreateGenEds();
    }

    public ArrayList getTable()
    {
        return genEds;
    }

    /**
     * setSelectedFields receives an array which contains a list of selected
     * attributes.
     *
     * @param selected represents the an int[] array with the index positions of
     * selected attributes 0 is the first attribute
     */
    public void setSelectedFields(int[] selected)
    {
        selectedFields = selected;
    }

    /**
     *
     * @return an int[] array with the index positions of selected attributes
     */
    public int[] getSelectedFields()
    {
        return selectedFields;
    }

    /**
     *
     * @return an ArrayList of Strings with the attribute names of a class that
     * implements this interface.
     */
    public ArrayList<String> getHeaders()
    {

        if (selectedFields.length == 0)
        {
            return genEds.get(0).getAttributesNames();
        }

        ArrayList<String> headers = new ArrayList<String>();

        for (int i : selectedFields)
        {
            headers.add(genEds.get(0).getAttributeName(i));
        }
        return headers;

    }

    /**
     * getLine returns an ArrayList of Strings with all the attribute values of
     * an object in the data ArrayList
     *
     * @param line represents the object position in the data ArrayList
     * @return
     */
    public ArrayList<String> getLine(int line)
    {
        if (selectedFields.length == 0)
        {
            return genEds.get(line).getAttributes();
        }

        ArrayList<String> lists = new ArrayList<String>();
        for (int x : selectedFields)
        {
            lists.add(genEds.get(line).getAttribute(x));
        }
        return lists;
    }

    /**
     * getLines return a list of lines defined by a range. It uses getLine(int
     * line) method.
     *
     * @param firstLine is the first line of a range to be returned
     * @param lastLine is the last line of a range to be returned
     * @return an ArrayList of ArrayLists with Strings
     */
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine)
    {
        ArrayList<ArrayList<String>> lines = new ArrayList<ArrayList<String>>();

        for (int i = firstLine; i < lastLine + 1; i++)
        {
            lines.add(getLine(i));
        }
        return lines;
    }

    public void CreateGenEds()
    {
        genEd ge1 = new genEd("Writing/Speaking", "GWS");
        genEd ge2 = new genEd("Quantification", "GQ");
        genEd ge3 = new genEd("Arts", "GA");
        genEd ge4 = new genEd("Humanities", "GH");
        genEd ge5 = new genEd("Health and Wellness", "GHW");
        genEd ge6 = new genEd("Natural Sciences", "GN");
        genEd ge7 = new genEd("Social and Behavioral Sciences", "GS");
        genEd ge8 = new genEd("United States Cultures", "US");
        genEd ge9 = new genEd("International Cultures", "IL");

        genEds.add(ge1);
        genEds.add(ge2);
        genEds.add(ge3);
        genEds.add(ge4);
        genEds.add(ge5);
        genEds.add(ge6);
        genEds.add(ge7);
        genEds.add(ge8);
        genEds.add(ge9);
    }

    /**
     * @return the begin
     */
    public int getBegin()
    {
        return begin;
    }

    /**
     * @param begin the begin to set
     */
    public void setBegin(int begin)
    {
        this.begin = begin;
    }

    /**
     * @return the linesToDisplay
     */
    public int getLinesToDisplay()
    {
        return linesToDisplay;
    }

    /**
     * @param linesToDisplay the linesToDisplay to set
     */
    public void setLinesToDisplay(int linesToDisplay)
    {
        this.linesToDisplay = linesToDisplay;
    }

    /**
     * @return the end
     */
    public int getEnd()
    {
        return end;
    }

    /**
     * @param end the end to set
     */
    public void setEnd(int end)
    {
        this.end = end;
    }

}
